// PolyCards — Main Application Logic
// Vanilla JS, no framework dependencies

// ==========================================
//  CONFIGURATION
// ==========================================

const isPremiumUser = false; // Set true to unlock all levels
const FREE_LEVELS = 6;
const TOTAL_LEVELS = 30;
const CARDS_PER_LEVEL = 50;

// ==========================================
//  STATE
// ==========================================

let state = {
  direction: 'fr-en', // 'fr-en' | 'en-fr'
  currentLevel: null,
  cards: [],
  cardIndex: 0,
  knew: 0,
  missed: 0,
  flipped: false,
  transitioning: false,
  premium: isPremiumUser,
};

// ==========================================
//  FLAG HELPER
// ==========================================

const FLAG_URLS = {
  fr: 'https://flagcdn.com/w40/fr.png',
  gb: 'https://flagcdn.com/w40/gb.png',
};

function flagHTML(code, size = 'sm') {
  const alt = code === 'fr' ? 'French' : 'English';
  return `<img src="${FLAG_URLS[code]}" alt="${alt}" class="flag-${size}" />`;
}

// ==========================================
//  SOUND ENGINE (Web Audio API)
// ==========================================

let _audioCtx = null;
let isMuted = localStorage.getItem('polycards_muted') === 'true';

function getAudioCtx() {
  if (!_audioCtx) {
    _audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  if (_audioCtx.state === 'suspended') _audioCtx.resume();
  return _audioCtx;
}

function playTone({ type = 'sine', freq, freqEnd, gain = 0.12, duration, delay = 0 }) {
  if (isMuted) return;
  try {
    const ctx = getAudioCtx();
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();
    osc.connect(gainNode);
    gainNode.connect(ctx.destination);
    const t = ctx.currentTime + delay;
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (freqEnd) osc.frequency.exponentialRampToValueAtTime(freqEnd, t + duration);
    gainNode.gain.setValueAtTime(gain, t);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    osc.start(t);
    osc.stop(t + duration + 0.01);
  } catch (_) {}
}

function soundClick() {
  playTone({ type: 'sine', freq: 880, freqEnd: 660, gain: 0.1, duration: 0.07 });
}

function soundFlip() {
  playTone({ type: 'sine', freq: 280, freqEnd: 520, gain: 0.07, duration: 0.13 });
  playTone({ type: 'sine', freq: 520, freqEnd: 380, gain: 0.04, duration: 0.1, delay: 0.08 });
}

function soundCorrect() {
  playTone({ type: 'sine', freq: 523.25, gain: 0.11, duration: 0.16 });
  playTone({ type: 'sine', freq: 783.99, gain: 0.11, duration: 0.20, delay: 0.11 });
}

function soundWrong() {
  playTone({ type: 'triangle', freq: 220, freqEnd: 140, gain: 0.09, duration: 0.18 });
}

function soundLevelComplete() {
  const notes = [523.25, 659.25, 783.99, 1046.5];
  notes.forEach((freq, i) => {
    playTone({ type: 'sine', freq, gain: 0.13, duration: 0.22, delay: i * 0.13 });
  });
}

function toggleMute() {
  isMuted = !isMuted;
  localStorage.setItem('polycards_muted', String(isMuted));
  updateMuteBtn();
}

function updateMuteBtn() {
  const btn = document.getElementById('btn-mute');
  if (!btn) return;
  btn.textContent = isMuted ? '🔇' : '🔊';
  btn.title = isMuted ? 'Unmute sounds' : 'Mute sounds';
  btn.setAttribute('aria-label', isMuted ? 'Unmute sounds' : 'Mute sounds');
}

// ==========================================
//  PROGRESS (localStorage)
// ==========================================

function loadProgress() {
  try {
    return JSON.parse(localStorage.getItem('polycards_progress') || '{}');
  } catch {
    return {};
  }
}

function saveProgress(level, data) {
  const progress = loadProgress();
  progress[level] = data;
  localStorage.setItem('polycards_progress', JSON.stringify(progress));
}

function resetProgress() {
  localStorage.removeItem('polycards_progress');
}

function isLevelCompleted(level) {
  const progress = loadProgress();
  return !!(progress[level] && progress[level].completed);
}

// ==========================================
//  WORD DATA HELPERS
// ==========================================

function getWordsForLevel(level) {
  const words = window.__POLYCARDS_WORDS__ || [];
  const realWords = words.filter(w => w.level === level);

  // If we have exactly 50, return them
  if (realWords.length >= CARDS_PER_LEVEL) {
    return realWords.slice(0, CARDS_PER_LEVEL);
  }

  // Otherwise, generate placeholders to fill to 50
  const filled = [...realWords];
  const categories = ['Vocabulary', 'Grammar', 'Expressions', 'Phrases'];
  const difficulties = ['easy', 'medium', 'hard'];

  while (filled.length < CARDS_PER_LEVEL) {
    const idx = filled.length;
    filled.push({
      id: level * 100 + idx,
      french: `[mot ${idx + 1} - niveau ${level}]`,
      english: `[word ${idx + 1} - level ${level}]`,
      level,
      category: categories[idx % categories.length],
      difficulty: difficulties[idx % difficulties.length],
    });
  }
  return filled;
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ==========================================
//  SCREEN NAVIGATION
// ==========================================

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const screen = document.getElementById(id);
  if (screen) screen.classList.add('active');
}

// ==========================================
//  LANDING SCREEN
// ==========================================

document.getElementById('btn-start').addEventListener('click', () => {
  showScreen('screen-direction');
});

// ==========================================
//  DIRECTION SELECTOR
// ==========================================

document.getElementById('back-from-direction').addEventListener('click', () => {
  showScreen('screen-landing');
});

document.getElementById('dir-fr-en').addEventListener('click', () => {
  soundClick();
  state.direction = 'fr-en';
  goToLevels();
});

document.getElementById('dir-en-fr').addEventListener('click', () => {
  soundClick();
  state.direction = 'en-fr';
  goToLevels();
});

// ==========================================
//  LEVELS SCREEN
// ==========================================

function goToLevels() {
  renderLevels();
  showScreen('screen-levels');
}

document.getElementById('back-from-levels').addEventListener('click', () => {
  showScreen('screen-direction');
});

document.getElementById('btn-reset-progress').addEventListener('click', () => {
  if (confirm('Reset all progress? This cannot be undone.')) {
    resetProgress();
    renderLevels();
  }
});

function renderLevels() {
  // Update mode badge
  const modeBadge = document.getElementById('current-mode-badge');
  modeBadge.innerHTML = state.direction === 'fr-en'
    ? `${flagHTML('fr')} French → English ${flagHTML('gb')}`
    : `${flagHTML('gb')} English → French ${flagHTML('fr')}`;

  const grid = document.getElementById('levels-grid');
  grid.innerHTML = '';

  const isPremium = state.premium;

  for (let level = 1; level <= TOTAL_LEVELS; level++) {
    const isLocked = !isPremium && level > FREE_LEVELS;
    const completed = isLevelCompleted(level);

    const btn = document.createElement('button');
    btn.className = 'level-btn' + (isLocked ? ' locked' : '') + (completed ? ' completed' : '');
    btn.setAttribute('data-level', level);
    btn.setAttribute('aria-label', `Level ${level}${isLocked ? ' (Premium)' : ''}`);

    if (isLocked) {
      btn.innerHTML = `
        <span class="level-num">${level}</span>
        <span class="lock-icon">🔒</span>
      `;
    } else {
      btn.innerHTML = `
        <span class="level-num">${level}</span>
        <span class="level-sub">${completed ? '✓' : '50 cards'}</span>
      `;
    }

    btn.addEventListener('click', () => {
      if (isLocked) {
        openPremiumModal();
      } else {
        startLevel(level);
      }
    });

    grid.appendChild(btn);
  }
}

// ==========================================
//  FLASHCARD SCREEN
// ==========================================

function startLevel(level) {
  state.currentLevel = level;
  state.cards = shuffle(getWordsForLevel(level));
  state.cardIndex = 0;
  state.knew = 0;
  state.missed = 0;
  state.flipped = false;
  state.transitioning = false;

  // Reset UI
  document.getElementById('flashcard-level-badge').textContent = `Level ${level}`;
  document.getElementById('count-total').textContent = state.cards.length;
  updateCardUI();
  resetFlip();
  updateActionRow(false);

  showScreen('screen-flashcard');
}

document.getElementById('back-from-flashcard').addEventListener('click', () => {
  goToLevels();
});

// Flip card on click
document.getElementById('flashcard').addEventListener('click', () => {
  if (!state.flipped) {
    flipCard();
  }
});

// Keyboard support
document.addEventListener('keydown', (e) => {
  const screen = document.querySelector('.screen.active');
  if (!screen) return;
  const id = screen.id;

  if (id === 'screen-flashcard') {
    if (e.key === ' ' || e.key === 'Enter') {
      e.preventDefault();
      if (!state.flipped) {
        flipCard();
      }
    }
    if (state.flipped && !state.transitioning) {
      if (e.key === 'ArrowLeft' || e.key === '1') handleMissed();
      if (e.key === 'ArrowRight' || e.key === '2') handleKnew();
      if (e.key === 'ArrowDown' || e.key === 'n') handleNext();
    }
  }
});

function flipCard() {
  if (state.transitioning) return;
  soundFlip();
  state.flipped = true;
  document.getElementById('card-inner').classList.add('flipped');
  updateActionRow(true);
  document.getElementById('flip-hint').style.visibility = 'hidden';
}

function resetFlip() {
  state.flipped = false;
  const inner = document.getElementById('card-inner');
  inner.classList.remove('flipped');
  inner.classList.remove('to-edge');
  document.getElementById('flip-hint').style.visibility = 'visible';
}

function updateCardUI() {
  const card = state.cards[state.cardIndex];
  if (!card) return;

  const isFrEn = state.direction === 'fr-en';

  // Front
  document.getElementById('front-lang').innerHTML = isFrEn
    ? `${flagHTML('fr', 'md')} French`
    : `${flagHTML('gb', 'md')} English`;
  document.getElementById('front-word').textContent = isFrEn ? card.french : card.english;
  document.getElementById('front-category').textContent = card.category;

  // Back
  document.getElementById('back-lang').innerHTML = isFrEn
    ? `${flagHTML('gb', 'md')} English`
    : `${flagHTML('fr', 'md')} French`;
  document.getElementById('back-word').textContent = isFrEn ? card.english : card.french;
  document.getElementById('back-category').textContent = card.category;

  const diffEl = document.getElementById('back-difficulty');
  diffEl.textContent = card.difficulty;
  diffEl.className = `card-difficulty-tag diff-${card.difficulty}`;

  // Progress bar
  const pct = (state.cardIndex / state.cards.length) * 100;
  document.getElementById('progress-bar').style.width = pct + '%';

  // Card index
  document.getElementById('card-index').textContent = `${state.cardIndex + 1} / ${state.cards.length}`;

  // Counters
  document.getElementById('cnt-knew').textContent = state.knew;
  document.getElementById('cnt-missed').textContent = state.missed;
  document.getElementById('count-correct').textContent = state.knew;
}

function updateActionRow(visible) {
  const row = document.getElementById('action-row');
  if (visible) {
    row.classList.remove('hidden');
  } else {
    row.classList.add('hidden');
  }
}

document.getElementById('btn-knew').addEventListener('click', handleKnew);
document.getElementById('btn-missed').addEventListener('click', handleMissed);
document.getElementById('btn-next').addEventListener('click', handleNext);

function handleKnew() {
  if (!state.flipped || state.transitioning) return;
  soundCorrect();
  state.knew++;
  nextCard();
}

function handleMissed() {
  if (!state.flipped || state.transitioning) return;
  soundWrong();
  state.missed++;
  nextCard();
}

function handleNext() {
  if (state.transitioning) return;
  nextCard();
}

function nextCard() {
  const nextIndex = state.cardIndex + 1;
  const inner = document.getElementById('card-inner');

  // Helper: one-shot transitionend listener filtered to the transform property
  function onTransformEnd(el, callback) {
    function handler(e) {
      if (e.propertyName !== 'transform') return;
      el.removeEventListener('transitionend', handler);
      callback();
    }
    el.addEventListener('transitionend', handler);
  }

  // ── Last card in level ──────────────────────────────────────────────────────
  if (nextIndex >= state.cards.length) {
    if (!state.flipped) {
      finishLevel();
      return;
    }
    // Flip is showing — un-flip cleanly before ending
    state.transitioning = true;
    updateActionRow(false);

    // Phase 1: 180deg → 90deg
    inner.classList.remove('flipped');
    inner.classList.add('to-edge');
    onTransformEnd(inner, () => {
      // Phase 2: 90deg → 0deg
      inner.classList.remove('to-edge');
      onTransformEnd(inner, () => {
        state.flipped = false;
        state.transitioning = false;
        finishLevel();
      });
    });
    return;
  }

  // ── Card not flipped — instant swap, no animation needed ───────────────────
  if (!state.flipped) {
    state.cardIndex = nextIndex;
    updateCardUI();
    updateActionRow(false);
    document.getElementById('flip-hint').style.visibility = 'visible';
    return;
  }

  // ── Card is flipped — two-phase event-driven un-flip ───────────────────────
  state.transitioning = true;
  updateActionRow(false);

  // Phase 1: 180deg → 90deg  (ease-in, card accelerates to edge-on)
  // Removing .flipped and adding .to-edge simultaneously so the browser
  // sees one style recalc: current=180deg, target=90deg, using .to-edge timing.
  inner.classList.remove('flipped');
  inner.classList.add('to-edge');

  onTransformEnd(inner, () => {
    // The transitionend callback fires AFTER the CSS transition fully completes.
    // The card is now provably at rotateY(90deg) — completely edge-on, invisible.
    // This is the only safe moment to swap content.
    state.flipped = false;
    state.cardIndex = nextIndex;
    updateCardUI();

    // Phase 2: 90deg → 0deg  (ease-out, front face swings into view)
    // Removing .to-edge makes the default .card-inner transition take over,
    // animating from the current 90deg back to 0deg.
    inner.classList.remove('to-edge');

    onTransformEnd(inner, () => {
      // Front face is fully visible — unlock all interaction
      state.transitioning = false;
      document.getElementById('flip-hint').style.visibility = 'visible';
    });
  });
}

// ==========================================
//  END SCREEN
// ==========================================

function finishLevel() {
  const total = state.cards.length;
  const pct = Math.round((state.knew / total) * 100);

  // Save progress
  saveProgress(state.currentLevel, {
    completed: true,
    score: pct,
    knew: state.knew,
    missed: state.missed,
    total,
  });

  // Determine trophy/title
  let trophy = '🏆';
  let title = 'Level Complete!';
  let message = '';

  if (pct >= 90) {
    trophy = '🌟';
    title = 'Outstanding!';
    message = 'Incredible performance! You really know this material.';
  } else if (pct >= 70) {
    trophy = '🏆';
    title = 'Great Job!';
    message = 'Well done! A little more practice and you\'ll have it mastered.';
  } else if (pct >= 50) {
    trophy = '💪';
    title = 'Keep Going!';
    message = 'Good effort! Try again to improve your score.';
  } else {
    trophy = '📚';
    title = 'Keep Practicing!';
    message = 'Don\'t give up — retry this level to reinforce the words.';
  }

  document.getElementById('end-trophy').textContent = trophy;
  document.getElementById('end-title').textContent = title;
  document.getElementById('end-score-pct').textContent = pct + '%';
  document.getElementById('end-knew').textContent = state.knew;
  document.getElementById('end-missed').textContent = state.missed;
  document.getElementById('end-message').textContent = message;

  // Animate ring
  const circumference = 2 * Math.PI * 50; // r=50 → ~314.16
  const offset = circumference - (pct / 100) * circumference;
  const ringFill = document.getElementById('ring-fill');

  // Need gradient in SVG
  const svg = ringFill.closest('svg');
  if (!svg.querySelector('defs')) {
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    defs.innerHTML = `
      <linearGradient id="ringGrad" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%"   stop-color="#6366f1"/>
        <stop offset="100%" stop-color="#a855f7"/>
      </linearGradient>
    `;
    svg.appendChild(defs);
    ringFill.setAttribute('stroke', 'url(#ringGrad)');
  }

  ringFill.style.strokeDashoffset = circumference;
  setTimeout(() => {
    ringFill.style.strokeDashoffset = offset;
  }, 100);

  // Next level button
  const nextLevelBtn = document.getElementById('btn-next-level');
  const nextLevel = state.currentLevel + 1;

  if (nextLevel > TOTAL_LEVELS) {
    nextLevelBtn.textContent = 'All Done! 🎉';
    nextLevelBtn.disabled = true;
  } else {
    const isNextLocked = !state.premium && nextLevel > FREE_LEVELS;
    nextLevelBtn.textContent = isNextLocked ? `Level ${nextLevel} 🔒` : `Level ${nextLevel} →`;
    nextLevelBtn.disabled = false;
  }

  soundLevelComplete();
  showScreen('screen-end');
}

document.getElementById('btn-retry').addEventListener('click', () => {
  startLevel(state.currentLevel);
});

document.getElementById('btn-next-level').addEventListener('click', () => {
  const nextLevel = state.currentLevel + 1;
  if (nextLevel > TOTAL_LEVELS) return;
  const isLocked = !state.premium && nextLevel > FREE_LEVELS;
  if (isLocked) {
    openPremiumModal();
  } else {
    startLevel(nextLevel);
  }
});

document.getElementById('btn-back-levels').addEventListener('click', () => {
  goToLevels();
});

// ==========================================
//  PREMIUM MODAL
// ==========================================

function openPremiumModal() {
  const modal = document.getElementById('modal-premium');
  modal.style.display = 'flex';
  modal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
}

function closePremiumModal() {
  const modal = document.getElementById('modal-premium');
  modal.style.display = 'none';
  modal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
}

document.getElementById('modal-close').addEventListener('click', closePremiumModal);
document.getElementById('modal-premium').addEventListener('click', (e) => {
  if (e.target === e.currentTarget) closePremiumModal();
});

document.getElementById('btn-upgrade').addEventListener('click', () => {
  alert('Premium upgrade coming soon! Use the demo unlock below to try premium levels now.');
});

document.getElementById('btn-demo-premium').addEventListener('click', () => {
  state.premium = true;
  closePremiumModal();
  renderLevels();

  // Show a quick toast
  showToast('🎉 Premium unlocked! All 30 levels are now available.');
});

// ==========================================
//  TOAST NOTIFICATION
// ==========================================

function showToast(message) {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);

  // Inject toast styles if not present
  if (!document.getElementById('toast-styles')) {
    const style = document.createElement('style');
    style.id = 'toast-styles';
    style.textContent = `
      .toast {
        position: fixed;
        bottom: 32px;
        left: 50%;
        transform: translateX(-50%) translateY(20px);
        background: #1e2330;
        color: #f0f2f8;
        border: 1px solid rgba(99,102,241,0.4);
        border-radius: 999px;
        padding: 12px 24px;
        font-size: 14px;
        font-weight: 500;
        z-index: 9999;
        white-space: nowrap;
        box-shadow: 0 8px 32px rgba(0,0,0,0.5);
        opacity: 0;
        transition: opacity 0.3s, transform 0.3s;
      }
      .toast.show {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
      }
    `;
    document.head.appendChild(style);
  }

  requestAnimationFrame(() => {
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 350);
    }, 3000);
  });
}

// ==========================================
//  INIT
// ==========================================

document.getElementById('btn-mute').addEventListener('click', toggleMute);

// Wait for words to be available
function init() {
  if (!window.__POLYCARDS_WORDS__) {
    setTimeout(init, 50);
    return;
  }
  updateMuteBtn();
  showScreen('screen-landing');
}

init();
